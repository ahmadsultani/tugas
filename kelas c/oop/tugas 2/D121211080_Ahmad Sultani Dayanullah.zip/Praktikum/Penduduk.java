public interface Penduduk {
  String warganegara = "Indonesia";
  void setNama(String nama);
  void setNik(String nik);
}
