public interface Karyawan extends Penduduk {
  void setJabatan(String jabatan);

}
