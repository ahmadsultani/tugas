public interface Mahasiswa {
  void setUniversitas(String universitas);
}
