public interface GajiBersih {
  void setNama(String nama);
  void setGaji(long gaji);
}
