public class GajiBulanan implements GajiBersih {
  private String nama;
  private long gaji;

  public String getNama() {
    return nama;
  }

  public void setNama(String nama) {
    this.nama = nama;
  }

  public long getGaji() {
    return gaji;
  }

  public void setGaji(long gaji) {
    this.gaji = gaji;
  }
}
